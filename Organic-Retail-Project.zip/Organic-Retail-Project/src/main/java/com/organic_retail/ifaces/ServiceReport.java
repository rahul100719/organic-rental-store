package com.organic_retail.ifaces;
import java.util.*;
import java.util.Locale.Category;

import com.organic_retail.item.Items;
//IntferFace for basic functionality in project
public interface ServiceReport 
{
    void buyItem(String itemCode,int quantity);
    List<Items> dailyReport();
    List<Items> monthlyReport(int month,int topN,int day);
}
