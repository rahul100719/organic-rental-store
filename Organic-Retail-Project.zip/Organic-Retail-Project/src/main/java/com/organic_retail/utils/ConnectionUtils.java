package com.organic_retail.utils;
import java.sql.*;
import java.util.Properties;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.io.*;
public class ConnectionUtils {
      public static Connection getMyConnection() {
    	  Connection con=null;
    	  try {
    	  
    	  String fileName="resources/DbConnections.properties";
    	  InputStream inStream=ConnectionUtils.class.getClassLoader().getResourceAsStream(fileName);
    	  
    	
//    	  System.out.println(inStream);
    	  Properties prop=new Properties();
    	  prop.load(inStream);
    	  
    	  String url=prop.getProperty("database.url");
    	  String userName=prop.getProperty("database.userName");
    	  String userPassword=prop.getProperty("database.passWord");
    	  con=DriverManager.getConnection(url,userName,userPassword);
    	  }
    	  catch (IOException  | SQLException e ) {
			 e.printStackTrace();
		}
    	  return con;
      }
      public static String[] getPropsAsArray() throws IOException
      {
    	  String fileName="resources/DbConnections.properties";
    	  InputStream inStream=ConnectionUtils.class.getClassLoader().getResourceAsStream(fileName); 
    	  Properties prop=new Properties();
    	  prop.load(inStream);
    	  
    	  String url=prop.getProperty("database.url");
    	  String userName=prop.getProperty("database.userName");
    	  String userPassword=prop.getProperty("database.passWord");
            return  new String  []{url,userName,userPassword};
      }
      public static Connection getConnectionFromPool() {
    	  Connection connection=null;
    	  try {
			
    		  HikariConfig config=new HikariConfig();
    		  String values[]=getPropsAsArray();
    		  config.setJdbcUrl(values[0]);
    		  config.setUsername(values[1]);
    		  config.setPassword(values[2]);
    		  config.addDataSourceProperty("maximumPoolSize", "25");
    		  DataSource dataSource=new HikariDataSource(config);
    		  connection=dataSource.getConnection();
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}
    	  
    	  
    	  return connection;
      }
      public static void main(String []args)
      {
    	 System.out.println(getMyConnection()); 
      }
}