package com.organic_retail;

import java.sql.Connection;
import java.util.*;

import com.organic_retail.item.Items;
import com.organic_retail.services.ItemServices;
import com.organic_retail.utils.ConnectionUtils;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		int i=1;
		ConnectionUtils conUtils = new ConnectionUtils();
		Connection connection = conUtils.getMyConnection();
		ItemServices itemsService = new ItemServices(connection);
		itemsService.buyItem("103G", 15);
		List<Items> dailyReport = itemsService.dailyReport();
		Formatter f = new Formatter();
		f.format("%15s %15s %15s %15s  %15s", "S.No", "Item_Name", "Item_Code", "Total_Quantity",
				"Total_Cost");
		System.out.println(f);
//		System.out.println("Daily Report");
//		for (Items items : dailyReport) {
//			Formatter f1 = new Formatter();
//			System.out.println(f1.format("%15s %15s  %15s %15s %15s", 
//					i++, items.getItemName(),  
//					items.getItemCode(), items.getQuantity(),
//					items.getQuantity()*items.getPrice()));
//		}
		List<Items> monthlyReport=itemsService.monthlyReport(11, 4,11);
		for (Items items : monthlyReport) {
			Formatter f1 = new Formatter();
			System.out.println(f1.format("%15s %15s  %15s %15s %15s", 
					i++, items.getItemName(),  
					items.getItemCode(), items.getQuantity(),
					items.getQuantity()*items.getPrice()));
		}

//		System.out.println(itemsService.monthlyReport(11, 5));
		try {
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
