package com.organic_retail.category;

import com.organic_retail.item.Items;

public class Edible extends Items {
	private String itemCode;
	private String itemName;
	private double perUnitPrice;
	private String dateOfManufacture;
	private String dateOfExpire;
	private String typeOfFood;
	private int    quantity;
	public Edible() {
		super();
		
	}
	
	
	
	public Edible(String itemCode, double price, String itemName, int quantity, String itemCode2, String itemName2,
			double perUnitPrice, String dateOfManufacture, String dateOfExpire, String typeOfFood, int quantity2) {
		super(itemCode, price, itemName, quantity);
		itemCode = itemCode2;
		itemName = itemName2;
		this.perUnitPrice = perUnitPrice;
		this.dateOfManufacture = dateOfManufacture;
		this.dateOfExpire = dateOfExpire;
		this.typeOfFood = typeOfFood;
		quantity = quantity2;
	}



	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public double getPerUnitPrice() {
		return perUnitPrice;
	}
	public void setPerUnitPrice(double perUnitPrice) {
		this.perUnitPrice = perUnitPrice;
	}
	public String getDateOfManufacture() {
		return dateOfManufacture;
	}
	public void setDateOfManufacture(String dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}
	public String getDateOfExpire() {
		return dateOfExpire;
	}
	public void setDateOfExpire(String dateOfExpire) {
		this.dateOfExpire = dateOfExpire;
	}
	public String getTypeOfFood() {
		return typeOfFood;
	}
	public void setTypeOfFood(String typeOfFood) {
		this.typeOfFood = typeOfFood;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	

}
