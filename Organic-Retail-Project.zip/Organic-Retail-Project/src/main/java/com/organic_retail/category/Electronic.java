package com.organic_retail.category;

import com.organic_retail.item.Items;

public class Electronic extends Items {
	private String itemCode;
	private String itemName;
	private double perUnitPrice;
	private String size;
	private int    quantity;
	private int    warranty;
	private double wattage;
	public Electronic() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Electronic(String itemCode, double price, String itemName, int quantity) {
		super(itemCode, price, itemName, quantity);
		
	}
	public Electronic(String itemCode, double price, String itemName, int quantity, String itemCode2, String itemName2,
			double perUnitPrice, String size, int quantity2, int warranty, double wattage) {
		super(itemCode, price, itemName, quantity);
		itemCode = itemCode2;
		itemName = itemName2;
		this.perUnitPrice = perUnitPrice;
		this.size = size;
		quantity = quantity2;
		this.warranty = warranty;
		this.wattage = wattage;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public double getPerUnitPrice() {
		return perUnitPrice;
	}
	public void setPerUnitPrice(double perUnitPrice) {
		this.perUnitPrice = perUnitPrice;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getWarranty() {
		return warranty;
	}
	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}
	public double getWattage() {
		return wattage;
	}
	public void setWattage(double wattage) {
		this.wattage = wattage;
	}
	
	
	

}
