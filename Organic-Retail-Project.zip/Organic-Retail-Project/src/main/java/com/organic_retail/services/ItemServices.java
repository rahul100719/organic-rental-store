package com.organic_retail.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.organic_retail.ifaces.ServiceReport;
import com.organic_retail.item.Items;

//service class for whole functionality of Project
public class ItemServices implements ServiceReport {
	private static Items items = null;
	private Connection connection;
	private String soldTableName = "Sold_Products_Details";
	private String garmentsTableName = "Garments";
	private String electronicTableName = "Eclectronics";
	private String edibleTableName = "Edible";
	private String metaDataTableName = "metaDataOfProducts";
    
	// constructor for connection
	public ItemServices(Connection connection) {
		super();
		this.connection = connection;
		
	}

	// method for buy items and for maintaining record of it in database
	@Override
	public void buyItem(String itemCode, int quantity) {
		String cateogry = findCateogry(itemCode);
		items = findDetailByCateogry(cateogry, itemCode, quantity);
//		System.out.println(items);
		addToSellTable(items, cateogry);
	    

	}

	// method for daily report of sales
	@Override
	public List<Items> dailyReport() {
		List<Items> list = new ArrayList<>();
		String findCateogrySql = "Select * ,sum(quntity_sold) from " + soldTableName
				+ " where date_of_sold=? group by category order by sum(quntity_sold) ";
		try (PreparedStatement pstm = connection.prepareStatement(findCateogrySql)) {
			pstm.setDate(1, new Date(System.currentTimeMillis()));
			ResultSet cateogryDetail = pstm.executeQuery();
			while (cateogryDetail.next()) {
				Items item = new Items(cateogryDetail.getString("itemcode"), cateogryDetail.getDouble("price"),
						cateogryDetail.getString("itemName"), cateogryDetail.getInt("sum(quntity_sold)"));
				list.add(item);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
    //method for for monthly report on basis of particular month and  n
	@Override
	public List<Items> monthlyReport(int month, int topN,int day) {
		List<Items> list = new ArrayList<>();
		String findCateogrySql = "Select *,sum(quntity_sold) from " + soldTableName
				+ " where month(date_of_sold)=? and day(date_of_sold)=? group by itemCode order by total desc";
		try (PreparedStatement pstm = connection.prepareStatement(findCateogrySql)) {
			pstm.setInt(1, month);
			pstm.setInt(2, day);
			ResultSet cateogryDetail = pstm.executeQuery();
			while (cateogryDetail.next() && topN-- > 0) {
				Items item = new Items(cateogryDetail.getString("itemcode"), cateogryDetail.getDouble("price"),
						cateogryDetail.getString("itemName"), cateogryDetail.getInt("sum(quntity_sold)"));
				list.add(item);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
     //Sort Element By category
	public List<Items> monthlyReportByCateogry(String category) {
		List<Items> list = new ArrayList<>();
		String findCateogrySql = "Select * from " + soldTableName + " where category=?";
		try (PreparedStatement pstm = connection.prepareStatement(findCateogrySql)) {
			pstm.setString(1, category);
			ResultSet cateogryDetail = pstm.executeQuery();
			while (cateogryDetail.next()) {
				Items item = new Items(cateogryDetail.getString("itemcode"), cateogryDetail.getDouble("price"),
						cateogryDetail.getString("itemName"), cateogryDetail.getInt("quntity_sold"));
				list.add(item);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;

	}
   //method for finding the category from data base
	public String findCateogry(String itemCode) {
		String cateogry = "";
		String findCateogrySql = "Select * from " + metaDataTableName + " where itemCode=?";
		try (PreparedStatement pstm = connection.prepareStatement(findCateogrySql)) {
			pstm.setString(1, itemCode);
			ResultSet cateogryDetail = pstm.executeQuery();
			while (cateogryDetail.next()) {
				cateogry = cateogryDetail.getString("category");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return cateogry;
	}
    
	public Items findDetailByCateogry(String cateogry, String itemCode, int quantity) {
		String cateogryValue = "";
		switch (cateogry) {
		case "Garments":
			cateogryValue = garmentsTableName;
			break;
		case "Eclectronics":
			cateogryValue = electronicTableName;
			break;
		case "Edible":
			cateogryValue = edibleTableName;
			break;
		default:
			break;
		}
		String findCateogrySql = "Select * from " + cateogryValue + " where itemCode=?";
		try (PreparedStatement pstm = connection.prepareStatement(findCateogrySql)) {
			pstm.setString(1, itemCode);
			ResultSet tableDetail = pstm.executeQuery();
			while (tableDetail.next()) {
				items = new Items(itemCode, tableDetail.getDouble("price"), tableDetail.getString("itemName"),
						quantity);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return items;
	}
    //Method for storing data in sell table
	public boolean addToSellTable(Items item, String cateogry) {
		boolean res = false;
		String insertSql = "insert into " + soldTableName + " values(?,?,?,?,?,?,?)";
		try (PreparedStatement pstm = connection.prepareStatement(insertSql)) {
			pstm.setString(1, item.getItemCode());
			pstm.setDouble(2, item.getPrice());
			pstm.setInt(3, item.getQuantity());
			pstm.setString(4, cateogry);
			pstm.setDate(5, new Date(System.currentTimeMillis()));
			pstm.setString(6, item.getItemName());
			pstm.setDouble(7, item.getQuantity() * item.getPrice());
			int update = pstm.executeUpdate();

			if (update == 1)
				res = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

}
