package com.organic_retail.display;

public class SoldItemDisplay 
{
	private String itemCode;
	private String itemName;
	private String Category;
	private int    Quantity;
	private double totalCost;
	private double unitPrice;
	
	public SoldItemDisplay() {
		super();
	
	}
	public SoldItemDisplay(String itemCode, String itemName, String category, int quantity, double totalCost,
			double unitPrice) {
		super();
		this.itemCode = itemCode;
		this.itemName = itemName;
		this.Category = category;
		this.Quantity = quantity;
		this.totalCost = totalCost;
		this.unitPrice = unitPrice;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	public double getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	
}
