package com.organic_retail.test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.organic_retail.item.Items;
import com.organic_retail.services.ItemServices;
import com.organic_retail.utils.ConnectionUtils;

class TestOrganicRental {

	private static Connection connection=ConnectionUtils.getMyConnection();
	private ItemServices itemService=new ItemServices(connection);
	private Items item=new Items("104G",50,"Jeans",10) ;
	@BeforeAll
	@DisplayName(value = "Test for Not Null value of Connection")
	static void setUpBeforeClass() throws Exception {
		 assertNotNull(connection);
	}


    
	@Test
	@DisplayName(value ="test for ture value")
	void  TestForStoringValueInDatabase()
	{
		assertTrue(itemService.addToSellTable(item, "Garments"));
	}
	@Test
	@DisplayName(value ="test for metadata table value")
	void  TestForCategoryFromTable()
	{
		assertEquals("Edible", itemService.findCateogry("101Edi"));
	}
	@Test
	@Disabled
	void test() {
		fail("Not yet implemented");
	}

}
